Todos los ejercicios que estan desarrollados en funciones contienen un script llamado textExX.m desde el que se muestra como se llaman
a estas funciones.