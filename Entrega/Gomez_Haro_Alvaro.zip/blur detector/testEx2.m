blurrer("./images", "./output");
blurdetection("./output");